import { Navigate } from 'react-router-dom';
import { getToken } from '../auth/tokenManager';

export default function ProtectedRoute({ children, allow }) {
  const token = getToken();
  const user = JSON.parse(localStorage.getItem('user') || 'null');

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (allow && user) {
    const role =
      typeof user.role === 'string'
        ? user.role
        : user.role === 2
        ? 'Admin'
        : user.role === 1
        ? 'Employee'
        : 'Employee';

    if (!allow.includes(role)) {
      const fallback =
        role === 'Customer'
          ? '/my-tickets'
          : '/dashboard';

      return <Navigate to={fallback} replace />;
    }
  }

  return children;
}