import { Link, useNavigate } from 'react-router-dom';
import api from '../../api/axios';
import { setTokens } from '../../auth/tokenManager';
import { getFriendlyErrorMessage } from '../../utils/apiErrors';
import './Login.scss';
import { useState, useEffect } from "react";

function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState('employee'); // 'employee' | 'customer'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
  const message = sessionStorage.getItem("authMessage");

  if (message) {
    setError(message);
    sessionStorage.removeItem("authMessage");
  }
}, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const endpoint = mode === 'customer' ? '/auth/customer/login' : '/auth/login';
      const response = await api.post(endpoint, { email, password });
      const { token, refreshToken, user } = response.data;

      setTokens(token, refreshToken);
      localStorage.setItem('user', JSON.stringify(user));

      navigate(mode === 'customer' ? '/my-tickets' : '/dashboard');
    } catch (err) {
      setError(getFriendlyErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-icon">▥</div>
          <div>
            <h2>EMS</h2>
            <span>Management</span>
          </div>
        </div>

        <div className="login-toggle">
          <button
            type="button"
            className={mode === 'employee' ? 'active' : ''}
            onClick={() => setMode('employee')}
          >
            Employee / Admin
          </button>
          <button
            type="button"
            className={mode === 'customer' ? 'active' : ''}
            onClick={() => setMode('customer')}
          >
            Customer
          </button>
        </div>

        <div className="login-header">
          <h1>Welcome back</h1>
          <p>
            {mode === 'customer'
              ? 'Sign in to raise or track your support tickets.'
              : 'Sign in to manage your organization.'}
          </p>
        </div>

        {error && <div className="login-error">{error}</div>}

        <form className="login-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {mode === 'customer' && (
          <p className="register-link">
            New here? <Link to="/register">Create an account</Link>
          </p>
        )}
      </div>
    </div>
  );
}

export default Login;