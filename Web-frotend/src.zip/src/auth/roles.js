export function getRoleLabel(user) {
  if (!user) return "";

  if (typeof user.role === "string") {
    return user.role;
  }

  if (user.role === 2) return "Admin";
  if (user.role === 1) return "Employee";

  return "Employee";
}

export function isAdmin(user) {
  if (!user) return false;

  return (
    user.role === "Admin" ||
    user.role === "admin" ||
    user.role === 2
  );
}

export function isCustomer(user) {
  if (!user) return false;

  return (
    user.role === "Customer" ||
    user.role === "customer"
  );
}

export function isAgent(user) {
  if (!user) return false;

  return (
    user.role === "Employee" ||
    user.role === "employee" ||
    user.role === 1
  );
}